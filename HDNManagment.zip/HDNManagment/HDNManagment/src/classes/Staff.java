/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JFrame;

/**
 *
 * @author pc
 */
public class Staff {

    /**
     * @return the ID_Doctor
     */
    public int getID_Doctor() {
        return ID_Doctor;
    }

    /**
     * @param ID_Doctor the ID_Doctor to set
     */
    public void setID_Doctor(int ID_Doctor) {
        this.ID_Doctor = ID_Doctor;
    }

    /**
     * @return the ID_Clinic
     */
    public int getID_Clinic() {
        return ID_Clinic;
    }

    /**
     * @param ID_Clinic the ID_Clinic to set
     */
    public void setID_Clinic(int ID_Clinic) {
        this.ID_Clinic = ID_Clinic;
    }
    private int ID_NUMBER;
    private String DATEOFHIRING;
    private String FIRST_NAME;
    private String FAMILY_NAME;
    private String NATIONALITY;
    private String DATEOFBIRTH;
    private String ADDRESS;
    private String PHONE;
    private String E_MAIL;
    private String SOCIAL_STATUS;
private int ID_Doctor;
private int ID_Clinic;
private User user;

    public Staff() {
    }

    public Staff(int ID_NUMBER, String DATEOFHIRING, String FIRST_NAME, String FAMILY_NAME, String NATIONALITY, String DATEOFBIRTH, String ADDRESS, String PHONE, String E_MAIL, String SOCIAL_STATUS, int ID_Doctor, int ID_Clinic) {
        this.ID_NUMBER = ID_NUMBER;
        this.DATEOFHIRING = DATEOFHIRING;
        this.FIRST_NAME = FIRST_NAME;
        this.FAMILY_NAME = FAMILY_NAME;
        this.NATIONALITY = NATIONALITY;
        this.DATEOFBIRTH = DATEOFBIRTH;
        this.ADDRESS = ADDRESS;
        this.PHONE = PHONE;
        this.E_MAIL = E_MAIL;
        this.SOCIAL_STATUS = SOCIAL_STATUS;
        this.ID_Doctor = ID_Doctor;
        this.ID_Clinic = ID_Clinic;
    }

   
   public int insertStaff(JFrame frame) {
        int uID = 0;
        try {
            Staff user = this;
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;
            if (con != null) {
                String sql = "INSERT INTO STAFF"
                        + "(DATEOFHIRING ,GENDER  ,FIRST_NAME ,FAMILY_NAME,NATIONALITY"
                        + ",DATEOFBIRTH"
                        + ",ADDRESS,PHONE,E_MAIL,SOCIAL_STATUS,ID_DOCTOR,ID_CLINIC"
                        + ")"
                        + " values (?,?,?,?,?,?,?,?,?,?,?,?)";
                String currentDate=AdminSession.getCurrentDate();
                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);

                pst.setString(1, user.getDATEOFHIRING());
                pst.setString(2, user.user.gender);
                pst.setString(3, user.user.Firstname);
                pst.setString(4, user.user.Lastname);
                pst.setString(5, user.user.nationality);
                pst.setString(6, user.user.dateOfBirth);
                pst.setString(7, user.user.address);
                pst.setString(8, user.user.phone);
                pst.setString(9, user.user.email);
                pst.setString(10, user.user.socialStatus);
                pst.setInt(11, user.ID_Doctor);
                pst.setInt(12, user.ID_Clinic);
                pst.execute();
                pst.close();
                sql = "Select  ID_NUMBER from STAFF order by  ID_NUMBER desc";
                try {

                    pst = con.prepareStatement(sql);

                    ResultSet rsr = pst.executeQuery();

                    if (rsr.next()) {
                        uID = (int) rsr.getLong(1);
                        user.user.AddUser(AdminSession.typeStaff,uID ,frame);
                    }
                } catch (SQLException ex) {

                }
            }
            con.close();

        } catch (Exception we) {
            MessageManager.showFailedMessage(frame);
        }
        return uID;
       
    }
    public static Staff GetStaffById(int id) {
        ResultSet rs = null;
       Staff staff=null;
        try {
            Connection.openConnection();

            java.sql.Connection con = Connection.conn2;
            String sql = "select * from Staff where ID_NUMBER=?";
            PreparedStatement pst = null;
            pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            rs = pst.executeQuery();
            try {
                if ((rs != null) && (rs.next())) {

                    Staff p = new Staff(rs.getInt("ID_NUMBER"), 
                            rs.getString("DATEOFHIRING"),
                             rs.getString("FIRST_NAME")
                            ,rs.getString("FAMILY_NAME"),
                            rs.getString("NATIONALITY"), 
                            rs.getString("DATEOFBIRTH"),
                            rs.getString("ADDRESS"),
                            rs.getString("PHONE"),
                            rs.getString("E_MAIL"),
                            rs.getString("SOCIAL_STATUS"),
                           
                            rs.getInt("ID_DOCTOR"),
                            rs.getInt("ID_CLINIC")
                    );

                    return p;
                }

            } catch (SQLException ex) {

            }

        } catch (Exception e) {

        }
        return null;
    }

    public void updateStaff(JFrame jFrame) {

    }

    public void DeleteStaff(JFrame jFrame) {
    }

    public static ArrayList<Staff> GetAlls() {
        ResultSet rs = null;
        ArrayList<Staff> List = new ArrayList<>();
        return List;
    } 

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the ID_NUMBER
     */
    public int getID_NUMBER() {
        return ID_NUMBER;
    }

    /**
     * @param ID_NUMBER the ID_NUMBER to set
     */
    public void setID_NUMBER(int ID_NUMBER) {
        this.ID_NUMBER = ID_NUMBER;
    }

    /**
     * @return the DATEOFHIRING
     */
    public String getDATEOFHIRING() {
        return DATEOFHIRING;
    }

    /**
     * @param DATEOFHIRING the DATEOFHIRING to set
     */
    public void setDATEOFHIRING(String DATEOFHIRING) {
        this.DATEOFHIRING = DATEOFHIRING;
    }

    /**
     * @return the FIRST_NAME
     */
    public String getFIRST_NAME() {
        return FIRST_NAME;
    }

    /**
     * @param FIRST_NAME the FIRST_NAME to set
     */
    public void setFIRST_NAME(String FIRST_NAME) {
        this.FIRST_NAME = FIRST_NAME;
    }

    /**
     * @return the FAMILY_NAME
     */
    public String getFAMILY_NAME() {
        return FAMILY_NAME;
    }

    /**
     * @param FAMILY_NAME the FAMILY_NAME to set
     */
    public void setFAMILY_NAME(String FAMILY_NAME) {
        this.FAMILY_NAME = FAMILY_NAME;
    }

    /**
     * @return the NATIONALITY
     */
    public String getNATIONALITY() {
        return NATIONALITY;
    }

    /**
     * @param NATIONALITY the NATIONALITY to set
     */
    public void setNATIONALITY(String NATIONALITY) {
        this.NATIONALITY = NATIONALITY;
    }

    /**
     * @return the DATEOFBIRTH
     */
    public String getDATEOFBIRTH() {
        return DATEOFBIRTH;
    }

    /**
     * @param DATEOFBIRTH the DATEOFBIRTH to set
     */
    public void setDATEOFBIRTH(String DATEOFBIRTH) {
        this.DATEOFBIRTH = DATEOFBIRTH;
    }

    /**
     * @return the ADDRESS
     */
    public String getADDRESS() {
        return ADDRESS;
    }

    /**
     * @param ADDRESS the ADDRESS to set
     */
    public void setADDRESS(String ADDRESS) {
        this.ADDRESS = ADDRESS;
    }

    /**
     * @return the PHONE
     */
    public String getPHONE() {
        return PHONE;
    }

    /**
     * @param PHONE the PHONE to set
     */
    public void setPHONE(String PHONE) {
        this.PHONE = PHONE;
    }

    /**
     * @return the E_MAIL
     */
    public String getE_MAIL() {
        return E_MAIL;
    }

    /**
     * @param E_MAIL the E_MAIL to set
     */
    public void setE_MAIL(String E_MAIL) {
        this.E_MAIL = E_MAIL;
    }

    /**
     * @return the SOCIAL_STATUS
     */
    public String getSOCIAL_STATUS() {
        return SOCIAL_STATUS;
    }

    /**
     * @param SOCIAL_STATUS the SOCIAL_STATUS to set
     */
    public void setSOCIAL_STATUS(String SOCIAL_STATUS) {
        this.SOCIAL_STATUS = SOCIAL_STATUS;
    }
}
