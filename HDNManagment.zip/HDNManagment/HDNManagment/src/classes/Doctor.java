/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JFrame;

/**
 *
 * @author pc
 */
public class Doctor {

    private int ID_NUMBER;
    private String DATEOFHIRING;
    private String SPECIALIZATION;
    private String Occupation;
    private String FIRST_NAME;
    private String NAMEOFFATHER;
    private String FAMILY_NAME;
    private String NATIONALITY;
    private String DATEOFBIRTH;
    private String ADDRESS;
    private String PHONE;
    private String E_MAIL;
    private String SOCIAL_STATUS;
    private String GENDER;
    private  User user ;
    
    public Doctor() {
    }

    public Doctor(int ID_NUMBER, String DATEOFHIRING, String SPECIALIZATION, String Occupation, String FIRST_NAME, String NAMEOFFATHER, String FAMILY_NAME, String NATIONALITY, String DATEOFBIRTH, String ADDRESS, String PHONE, String E_MAIL, String SOCIAL_STATUS, String GENDER) {
        this.ID_NUMBER = ID_NUMBER;
        this.DATEOFHIRING = DATEOFHIRING;
        this.SPECIALIZATION = SPECIALIZATION;
        this.Occupation = Occupation;
        this.FIRST_NAME = FIRST_NAME;
        this.NAMEOFFATHER = NAMEOFFATHER;
        this.FAMILY_NAME = FAMILY_NAME;
        this.NATIONALITY = NATIONALITY;
        this.DATEOFBIRTH = DATEOFBIRTH;
        this.ADDRESS = ADDRESS;
        this.PHONE = PHONE;
        this.E_MAIL = E_MAIL;
        this.SOCIAL_STATUS = SOCIAL_STATUS;
        this.GENDER = GENDER;
        
    }

   

   

    /**
     * @return the ID_NUMBER
     */
    public int getID_NUMBER() {
        return ID_NUMBER;
    }

    /**
     * @param ID_NUMBER the ID_NUMBER to set
     */
    public void setID_NUMBER(int ID_NUMBER) {
        this.ID_NUMBER = ID_NUMBER;
    }

    /**
     * @return the DATEOFHIRING
     */
    public String getDATEOFHIRING() {
        return DATEOFHIRING;
    }

    /**
     * @param DATEOFHIRING the DATEOFHIRING to set
     */
    public void setDATEOFHIRING(String DATEOFHIRING) {
        this.DATEOFHIRING = DATEOFHIRING;
    }

    /**
     * @return the SPECIALIZATION
     */
    public String getSPECIALIZATION() {
        return SPECIALIZATION;
    }

    /**
     * @param SPECIALIZATION the SPECIALIZATION to set
     */
    public void setSPECIALIZATION(String SPECIALIZATION) {
        this.SPECIALIZATION = SPECIALIZATION;
    }

    /**
     * @return the FIRST_NAME
     */
    public String getFIRST_NAME() {
        return FIRST_NAME;
    }

    /**
     * @param FIRST_NAME the FIRST_NAME to set
     */
    public void setFIRST_NAME(String FIRST_NAME) {
        this.FIRST_NAME = FIRST_NAME;
    }

    /**
     * @return the NAMEOFFATHER
     */
    public String getNAMEOFFATHER() {
        return NAMEOFFATHER;
    }

    /**
     * @param NAMEOFFATHER the NAMEOFFATHER to set
     */
    public void setNAMEOFFATHER(String NAMEOFFATHER) {
        this.NAMEOFFATHER = NAMEOFFATHER;
    }

    /**
     * @return the FAMILY_NAME
     */
    public String getFAMILY_NAME() {
        return FAMILY_NAME;
    }

    /**
     * @param FAMILY_NAME the FAMILY_NAME to set
     */
    public void setFAMILY_NAME(String FAMILY_NAME) {
        this.FAMILY_NAME = FAMILY_NAME;
    }

    /**
     * @return the NATIONALITY
     */
    public String getNATIONALITY() {
        return NATIONALITY;
    }

    /**
     * @param NATIONALITY the NATIONALITY to set
     */
    public void setNATIONALITY(String NATIONALITY) {
        this.NATIONALITY = NATIONALITY;
    }

    /**
     * @return the DATEOFBIRTH
     */
    public String getDATEOFBIRTH() {
        return DATEOFBIRTH;
    }

    /**
     * @param DATEOFBIRTH the DATEOFBIRTH to set
     */
    public void setDATEOFBIRTH(String DATEOFBIRTH) {
        this.DATEOFBIRTH = DATEOFBIRTH;
    }

    /**
     * @return the ADDRESS
     */
    public String getADDRESS() {
        return ADDRESS;
    }

    /**
     * @param ADDRESS the ADDRESS to set
     */
    public void setADDRESS(String ADDRESS) {
        this.ADDRESS = ADDRESS;
    }

    /**
     * @return the PHONE
     */
    public String getPHONE() {
        return PHONE;
    }

    /**
     * @param PHONE the PHONE to set
     */
    public void setPHONE(String PHONE) {
        this.PHONE = PHONE;
    }

    /**
     * @return the E_MAIL
     */
    public String getE_MAIL() {
        return E_MAIL;
    }

    /**
     * @param E_MAIL the E_MAIL to set
     */
    public void setE_MAIL(String E_MAIL) {
        this.E_MAIL = E_MAIL;
    }

    /**
     * @return the SOCIAL_STATUS
     */
    public String getSOCIAL_STATUS() {
        return SOCIAL_STATUS;
    }

    /**
     * @param SOCIAL_STATUS the SOCIAL_STATUS to set
     */
    public void setSOCIAL_STATUS(String SOCIAL_STATUS) {
        this.SOCIAL_STATUS = SOCIAL_STATUS;
    }

    /**
     * @return the GENDER
     */
    public String getGENDER() {
        return GENDER;
    }

    /**
     * @param GENDER the GENDER to set
     */
    public void setGENDER(String GENDER) {
        this.GENDER = GENDER;
    }

    public int insertDoctor(JFrame frame) {
      int uID = 0;
        try {
            Doctor user = this;
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;
            if (con != null) {
                String sql = "INSERT INTO DOCTORS( DATEOFHIRING,SPECIALIZATION,"
                        + "FIRST_NAME,NAMEOFFATHER,FAMILY_NAME,NATIONALITY,"
                        + "DATEOFBIRTH,ADDRESS,PHONE,E_MAIL,SOCIAL_STATUS"
                        + ",GENDER  ,OCCUPATION"
                        + ")"
                        + " values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
                String currentDate=AdminSession.getCurrentDate();
                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);

                pst.setString(1, user.user.dateOfBirth);
                pst.setString(2, user.SPECIALIZATION);
                pst.setString(3, user.user.Firstname);
                pst.setString(4, user.NAMEOFFATHER);
                pst.setString(5, user.user.Lastname);
                pst.setString(6, user.user.nationality);
                pst.setString(7, user.user.dateOfBirth);
                pst.setString(8, user.user.address);
                pst.setString(9, user.user.phone);
                pst.setString(10, user.user.email);
                pst.setString(11, user.user.socialStatus);
                 pst.setString(12, user.user.gender);
                  pst.setString(13, user.Occupation);
                pst.execute();
                pst.close();
                sql = "Select IDNUMBER  from DOCTORS order by  IDNUMBER desc";
                try {

                    pst = con.prepareStatement(sql);

                    ResultSet rsr = pst.executeQuery();

                    if (rsr.next()) {
                        uID = (int) rsr.getLong(1);
                        user.user.AddUser(AdminSession.typeDoctor,uID ,frame);
                    }
                } catch (SQLException ex) {
                int ccc=0;
                }
            }
            con.close();

        } catch (Exception we) {
            MessageManager.showFailedMessage(frame);
        }
        return uID;
      
    }

    public void updateDoctor(JFrame jFrame) {

    }

    public void DeleteDoctor(JFrame jFrame) {
    }

    public static ArrayList<Doctor> GetAlls() {
        ResultSet rs = null;
        ArrayList<Doctor> List = new ArrayList<>();
        try {
            Connection.openConnection();

            java.sql.Connection con = Connection.conn2;
            String sql = "select * from DOCTORS";
            PreparedStatement pst = null;
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            try {
                while ((rs != null) && (rs.next())) {
                    Doctor p = new Doctor(rs.getInt("IDNUMBER"), 
                            rs.getString("DATEOFHIRING"),
                            rs.getString("SPECIALIZATION"), 
                            rs.getString("OCCUPATION"),
                            rs.getString("FIRST_NAME"),
                            rs.getString("NAMEOFFATHER")
                            ,rs.getString("FAMILY_NAME"),
                            rs.getString("NATIONALITY"),
                            rs.getString("DATEOFBIRTH"),
                            rs.getString("ADDRESS"), rs.getString("PHONE"),
                            rs.getString("E_MAIL"),
                            rs.getString("SOCIAL_STATUS"),
                            rs.getString("GENDER")
                    );

                    List.add(p);
                }

            } catch (SQLException ex) {

            }

        } catch (Exception e) {

        }
        return List;
    }
    public static ResultSet GetAllResultSet() {
        ResultSet rs = null;
        try {
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;

            if (con != null) {

                String sql = "select * from DOCTORS";

                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);
             
                rs = pst.executeQuery();

            }

        } catch (Exception e) {

        }
        return rs;
    }

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the Occupation
     */
    public String getOccupation() {
        return Occupation;
    }

    /**
     * @param Occupation the Occupation to set
     */
    public void setOccupation(String Occupation) {
        this.Occupation = Occupation;
    }
    public static Doctor GetDoctorById(int id) {
        ResultSet rs = null;
       Patient patient=null;
        try {
            Connection.openConnection();

            java.sql.Connection con = Connection.conn2;
            String sql = "select * from DOCTORS where IDNUMBER=?";
            PreparedStatement pst = null;
            pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            rs = pst.executeQuery();
            try {
                if ((rs != null) && (rs.next())) {

                    Doctor p = new Doctor(rs.getInt("IDNUMBER"), 
                            rs.getString("DATEOFHIRING"),
                            rs.getString("SPECIALIZATION"), 
                            rs.getString("OCCUPATION"),
                            rs.getString("FIRST_NAME"),
                            rs.getString("NAMEOFFATHER")
                            ,rs.getString("FAMILY_NAME"),
                            rs.getString("NATIONALITY"),
                            rs.getString("DATEOFBIRTH"),
                            rs.getString("ADDRESS"), rs.getString("PHONE"),
                            rs.getString("E_MAIL"),
                            rs.getString("SOCIAL_STATUS"),
                            rs.getString("GENDER")
                    );

                    return p;
                }

            } catch (SQLException ex) {

            }

        } catch (Exception e) {

        }
        return null;
    }
}
