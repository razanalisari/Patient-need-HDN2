/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JFrame;

/**
 *
 * @author pc
 */
public class Clinic {
    private int CLINICNUMBER;
    private String CLINICNAME;

    public Clinic() {
    }

    public Clinic(int CLINICNUMBER, String CLINICNAME) {
        this.CLINICNUMBER = CLINICNUMBER;
        this.CLINICNAME = CLINICNAME;
    }
     
    /**
     * @return the CLINICNUMBER
     */
    public int getCLINICNUMBER() {
        return CLINICNUMBER;
    }

    /**
     * @param CLINICNUMBER the CLINICNUMBER to set
     */
    public void setCLINICNUMBER(int CLINICNUMBER) {
        this.CLINICNUMBER = CLINICNUMBER;
    }

    /**
     * @return the CLINICNAME
     */
    public String getCLINICNAME() {
        return CLINICNAME;
    }

    /**
     * @param CLINICNAME the CLINICNAME to set
     */
    public void setCLINICNAME(String CLINICNAME) {
        this.CLINICNAME = CLINICNAME;
    }
     public int insertClinic(JFrame frame) {
        int uID = 0;
        try {
            Clinic obj = this;
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;
            if (con != null) {
                String sql = "INSERT INTO CLINIC(CLINICNAME"
                        + ")"
                        + " values (?)";
                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);

                pst.setString(1, obj.CLINICNAME);
             
                pst.execute();
                pst.close();
                sql = "Select  CLINICNUMBER from CLINIC order by  CLINICNUMBER desc";
                try {

                    pst = con.prepareStatement(sql);

                    ResultSet rsr = pst.executeQuery();

                    if (rsr.next()) {
                        uID = (int) rsr.getLong(1);
                         MessageManager.showSuccessMessage(frame,"CLinic added successfully");
                    }
                } catch (SQLException ex) {

                }
            }
            con.close();

        } catch (Exception we) {
            MessageManager.showFailedMessage(frame);
        }
        return uID;
    }
    public void updateCLINIC(JFrame jFrame) {
        try {
            Clinic obj = this;
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;
            if (con != null) {
                String sql = "update CLINIC set CLINICNAME='" + this.CLINICNAME + "'"
                      
                        + " where CLINICNUMBER=" + this.CLINICNUMBER;
                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);

                pst.executeUpdate();
                pst.close();
                MessageManager.showSuccessUpdateMessage(jFrame);
            } else {
                MessageManager.showFailedMessage(jFrame);
            }
            con.close();
        } catch (Exception we) {
            MessageManager.showFailedMessage(jFrame);
        }

    }
    public void Delete(JFrame jFrame) {
        try {
            Clinic obj = this;
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;
            if (con != null) {
               
                String sql = "Delete from  CLINIC where CLINICNUMBER=?";
                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);
                pst.setInt(1, this.CLINICNUMBER);
                pst.executeUpdate();
                pst.close();
                MessageManager.showSuccessMessage(jFrame,"Information added successfully");
                
            } else {
                MessageManager.showFailedMessage(jFrame);
            }
            con.close();
        } catch (Exception we) {
            MessageManager.showFailedMessage(jFrame,"Can't delete clinc because it contains related information");
        }

    }
    public static ResultSet GetAllResultSet() {
        ResultSet rs = null;
        try {
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;

            if (con != null) {

                String sql = "select * from CLINIC";

                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);
             
                rs = pst.executeQuery();

            }

        } catch (Exception e) {

        }
        return rs;
    }
    public static ArrayList<Clinic> GetAlls() {
        ResultSet rs = null;
        ArrayList<Clinic> List = new ArrayList<>();
        try {
            Connection.openConnection();

            java.sql.Connection con = Connection.conn2;
            String sql = "select * from Clinic";
            PreparedStatement pst = null;
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            try {
                while ((rs != null) && (rs.next())) {

                    Clinic p = new Clinic(rs.getInt("CLINICNUMBER"), rs.getString("CLINICNAME")
                    );

                    List.add(p);
                }

            } catch (SQLException ex) {

            }

        } catch (Exception e) {

        }
        return List;
    }
}
