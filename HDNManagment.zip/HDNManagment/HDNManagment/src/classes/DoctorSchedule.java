/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JFrame;

/**
 *
 * @author pc
 */
public class DoctorSchedule {

    private int ID_NUMBER;
    private int ID_Doctor;
    private String DAYS;
    private String Times;
    private String doctorName;
    public DoctorSchedule() {
    }

    public DoctorSchedule(int ID_NUMBER, int ID_Doctor, String DAYS, String Times) {
        this.ID_NUMBER = ID_NUMBER;
        this.ID_Doctor = ID_Doctor;
        this.DAYS = DAYS;
        this.Times = Times;
    }
    public static ArrayList<DoctorSchedule> GetAlls() {
        ResultSet rs = null;
        ArrayList<DoctorSchedule> List = new ArrayList<>();
        try {
            Connection.openConnection();

            java.sql.Connection con = Connection.conn2;
            String sql = "select * from DOCTORSSCHEDUALE join DOCTORS on DOCTORS.IDNUMBER= DOCTORSSCHEDUALE.ID_DOCTOR";
                  
            PreparedStatement pst = null;
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            try {
                while ((rs != null) && (rs.next())) {

                    DoctorSchedule p = new DoctorSchedule(rs.getInt("ID_NUMBER")
                            ,rs.getInt("ID_DOCTOR")
                            , rs.getString("DAYS")
                            , rs.getString("TIMES")
                    );
                    p.setDoctorName(rs.getString("FIRST_NAME")+ " "+rs.getString("FAMILY_NAME"));
                    List.add(p);
                }

            } catch (SQLException ex) {

            }

        } catch (Exception e) {

        }
        return List;
    }
    public int inserDoctorSchedule(JFrame frame) {
        int uID = 0;
        try {
            DoctorSchedule obj = this;
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;
            if (con != null) {
                String sql = "INSERT INTO DOCTORSSCHEDUALE(ID_DOCTOR,"
                        + "DAYS,"
                        + "TIMES"
                      
                        + ")"
                        + " values (?,?,?)";
                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);
                pst.setInt(1, obj.ID_Doctor);
                pst.setString(2, obj.DAYS);
                pst.setString(3, obj.Times);
                
                pst.execute();
                pst.close();
                sql = "Select ID_NUMBER from DOCTORSSCHEDUALE order by ID_NUMBER desc";
                try {

                    pst = con.prepareStatement(sql);

                    ResultSet rsr = pst.executeQuery();

                    if (rsr.next()) {
                        uID = (int) rsr.getLong(1);
                         MessageManager.showSuccessMessage(frame,"Schedule added successfully");
                    }
                } catch (SQLException ex) {

                }
            }
            con.close();

        } catch (Exception we) {
            MessageManager.showFailedMessage(frame);
        }
        return uID;
       
    }
    /**
     * @return the ID_NUMBER
     */
    public int getID_NUMBER() {
        return ID_NUMBER;
    }

    /**
     * @param ID_NUMBER the ID_NUMBER to set
     */
    public void setID_NUMBER(int ID_NUMBER) {
        this.ID_NUMBER = ID_NUMBER;
    }

    /**
     * @return the ID_Doctor
     */
    public int getID_Doctor() {
        return ID_Doctor;
    }

    /**
     * @param ID_Doctor the ID_Doctor to set
     */
    public void setID_Doctor(int ID_Doctor) {
        this.ID_Doctor = ID_Doctor;
    }

    /**
     * @return the DAYS
     */
    public String getDAYS() {
        return DAYS;
    }

    /**
     * @param DAYS the DAYS to set
     */
    public void setDAYS(String DAYS) {
        this.DAYS = DAYS;
    }

    /**
     * @return the Times
     */
    public String getTimes() {
        return Times;
    }

    /**
     * @param Times the Times to set
     */
    public void setTimes(String Times) {
        this.Times = Times;
    }

    /**
     * @return the doctorName
     */
    public String getDoctorName() {
        return doctorName;
    }

    /**
     * @param doctorName the doctorName to set
     */
    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

}
