/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JFrame;

/**
 *
 * @author pc
 */
public class Patient {

    private int ID_NUMBER;
    private String BLOODTYPE;
    private String GENDER;
    private String FIRST_NAME;
    private String FAMILY_NAME;
    private int FILE_NO;
    private String DATETHEFILEWASOPENED;
    private String NATIONALITY;
    private String DATEOFBIRTH;
    private String ADDRESS;
    private String PHONE;
    private String E_MAIL;
    private String SOCIAL_STATUS;
    private User user;
    public Patient() {
    }

    public Patient(int ID_NUMBER, String BLOODTYPE, String GENDER, String FIRST_NAME, String FAMILY_NAME, int FILE_NO, String DATETHEFILEWASOPENED, String NATIONALITY, String DATEOFBIRTH, String ADDRESS, String PHONE, String E_MAIL, String SOCIAL_STATUS) {
        this.ID_NUMBER = ID_NUMBER;
        this.BLOODTYPE = BLOODTYPE;
        this.GENDER = GENDER;
        this.FIRST_NAME = FIRST_NAME;
        this.FAMILY_NAME = FAMILY_NAME;
        this.FILE_NO = FILE_NO;
        this.DATETHEFILEWASOPENED = DATETHEFILEWASOPENED;
        this.NATIONALITY = NATIONALITY;
        this.DATEOFBIRTH = DATEOFBIRTH;
        this.ADDRESS = ADDRESS;
        this.PHONE = PHONE;
        this.E_MAIL = E_MAIL;
        this.SOCIAL_STATUS = SOCIAL_STATUS;
    }

    public int getID_NUMBER() {
        return ID_NUMBER;
    }

    public void setID_NUMBER(int ID_NUMBER) {
        this.ID_NUMBER = ID_NUMBER;
    }

    public String getBLOODTYPE() {
        return BLOODTYPE;
    }

    public void setBLOODTYPE(String BLOODTYPE) {
        this.BLOODTYPE = BLOODTYPE;
    }

    public String getGENDER() {
        return GENDER;
    }

    public void setGENDER(String GENDER) {
        this.GENDER = GENDER;
    }

    public String getFIRST_NAME() {
        return FIRST_NAME;
    }

    public void setFIRST_NAME(String FIRST_NAME) {
        this.FIRST_NAME = FIRST_NAME;
    }

    public String getFAMILY_NAME() {
        return FAMILY_NAME;
    }

    public void setFAMILY_NAME(String FAMILY_NAME) {
        this.FAMILY_NAME = FAMILY_NAME;
    }

    public int getFILE_NO() {
        return FILE_NO;
    }

    public void setFILE_NO(int FILE_NO) {
        this.FILE_NO = FILE_NO;
    }

    public String getDATETHEFILEWASOPENED() {
        return DATETHEFILEWASOPENED;
    }

    public void setDATETHEFILEWASOPENED(String DATETHEFILEWASOPENED) {
        this.DATETHEFILEWASOPENED = DATETHEFILEWASOPENED;
    }

    public String getNATIONALITY() {
        return NATIONALITY;
    }

    public void setNATIONALITY(String NATIONALITY) {
        this.NATIONALITY = NATIONALITY;
    }

    public String getDATEOFBIRTH() {
        return DATEOFBIRTH;
    }

    public void setDATEOFBIRTH(String DATEOFBIRTH) {
        this.DATEOFBIRTH = DATEOFBIRTH;
    }

    public String getADDRESS() {
        return ADDRESS;
    }

    public void setADDRESS(String ADDRESS) {
        this.ADDRESS = ADDRESS;
    }

    public String getPHONE() {
        return PHONE;
    }

    public void setPHONE(String PHONE) {
        this.PHONE = PHONE;
    }

    public String getE_MAIL() {
        return E_MAIL;
    }

    public void setE_MAIL(String E_MAIL) {
        this.E_MAIL = E_MAIL;
    }

    public String getSOCIAL_STATUS() {
        return SOCIAL_STATUS;
    }

    public void setSOCIAL_STATUS(String SOCIAL_STATUS) {
        this.SOCIAL_STATUS = SOCIAL_STATUS;
    }
    public int insertPatien(JFrame frame) {
        int uID = 0;
        try {
            Patient user = this;
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;
            if (con != null) {
                String sql = "INSERT INTO PATIENT( BLOODTYPE,GENDER  ,FIRST_NAME ,FAMILY_NAME,FILE_NO,DATETHEFILEWASOPENED"
                        + ",NATIONALITY,DATEOFBIRTH"
                        + ",ADDRESS,PHONE,E_MAIL,SOCIAL_STATUS"
                        + ")"
                        + " values (?,?,?,?,?,?,?,?,?,?,?,?)";
                String currentDate=AdminSession.getCurrentDate();
                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);

                pst.setString(1, user.BLOODTYPE);
                pst.setString(2, user.user.gender);
                pst.setString(3, user.user.Firstname);
                pst.setString(4, user.user.Lastname);
                pst.setInt(5, user.FILE_NO);
                pst.setString(6, currentDate);
                pst.setString(7, user.user.nationality);
                pst.setString(8, user.user.dateOfBirth);
                pst.setString(9, user.user.address);
                pst.setString(10, user.user.phone);
                pst.setString(11, user.user.email);
                pst.setString(12, user.user.socialStatus);
                pst.execute();
                pst.close();
                sql = "Select  ID_NUMBER from PATIENT order by  ID_NUMBER desc";
                try {

                    pst = con.prepareStatement(sql);

                    ResultSet rsr = pst.executeQuery();

                    if (rsr.next()) {
                        uID = (int) rsr.getLong(1);
                        user.user.AddUser(AdminSession.typePatient, uID,frame);
                        
                    }
                } catch (SQLException ex) {

                }
            }
            con.close();

        } catch (Exception we) {
            MessageManager.showFailedMessage(frame);
        }
        return uID;
    }
    public void updatePatient(JFrame jFrame) {
        try {
            Patient paUser = this;
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;
            if (con != null) {
                String sql = "update PATIENT set BLOODTYPE='" + paUser.BLOODTYPE + "'"
                        + " ,GENDER ='" + paUser.GENDER + "'"
                        + " ,FIRST_NAME ='" + paUser.FIRST_NAME + "'"
                        + " , FAMILY_NAME='" + paUser.FAMILY_NAME + "'"
                        + " ,FILE_NO =" + paUser.FILE_NO + ""
                        + " ,DATETHEFILEWASOPENED ='" + paUser.DATETHEFILEWASOPENED + "'"
                        + " , NATIONALITY='" + paUser.NATIONALITY + "'"
                        + " ,DATEOFBIRTH ='" + paUser.DATEOFBIRTH + "'"
                        + " ,ADDRESS ='" + paUser.ADDRESS + "'"
                        + " ,PHONE ='" + paUser.PHONE + "'"
                        + " ,E_MAIL ='" + paUser.E_MAIL + "'"
                        + " ,SOCIAL_STATUS ='" + paUser.SOCIAL_STATUS + "'"
                        + " where ID_NUMBER=" + paUser.ID_NUMBER;
                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);

                pst.executeUpdate();
                pst.close();
                MessageManager.showSuccessUpdateMessage(jFrame);
            } else {
                MessageManager.showFailedMessage(jFrame);
            }
            con.close();
        } catch (Exception we) {
            MessageManager.showFailedMessage(jFrame);
        }

    }
    public void DeletePatient(JFrame jFrame) {
        try {
            Patient paUser = this;
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;
            if (con != null) {
                String sql = "Delete from PATIENT where ID_NUMBER=?";
                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);
                pst.setInt(1, this.ID_NUMBER);
                pst.executeUpdate();
                pst.close();
                MessageManager.showSuccessUpdateMessage(jFrame);
            } else {
                MessageManager.showFailedMessage(jFrame);
            }
            con.close();
        } catch (Exception we) {
            MessageManager.showFailedMessage(jFrame);
        }

    } 
    public static ArrayList<Patient> GetAlls() {
        ResultSet rs = null;
        ArrayList<Patient> List = new ArrayList<>();
        try {
            Connection.openConnection();

            java.sql.Connection con = Connection.conn2;
            String sql = "select * from PATIENT";
            PreparedStatement pst = null;
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();
            try {
                while ((rs != null) && (rs.next())) {

                    Patient p = new Patient(rs.getInt("ID_NUMBER"), rs.getString("BLOODTYPE"),
                            rs.getString("GENDER"), rs.getString("FIRST_NAME"), rs.getString("FAMILY_NAME"), rs.getInt("FILE_NO"),
                            rs.getString("DATETHEFILEWASOPENED"),
                            rs.getString("NATIONALITY"),
                            rs.getString("DATEOFBIRTH"),
                            rs.getString("ADDRESS"), rs.getString("PHONE"),
                            rs.getString("E_MAIL"),
                            rs.getString("SOCIAL_STATUS")
                    );

                    List.add(p);
                }

            } catch (SQLException ex) {

            }

        } catch (Exception e) {

        }
        return List;
    }
 public static Patient GetPatientById(int id) {
        ResultSet rs = null;
       Patient patient=null;
        try {
            Connection.openConnection();

            java.sql.Connection con = Connection.conn2;
            String sql = "select * from PATIENT where ID_NUMBER=?";
            PreparedStatement pst = null;
            pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            rs = pst.executeQuery();
            try {
                if ((rs != null) && (rs.next())) {

                    Patient p = new Patient(rs.getInt("ID_NUMBER"), rs.getString("BLOODTYPE"),
                            rs.getString("GENDER"), rs.getString("FIRST_NAME"), rs.getString("FAMILY_NAME"), rs.getInt("FILE_NO"),
                            rs.getString("DATETHEFILEWASOPENED"),
                            rs.getString("NATIONALITY"),
                            rs.getString("DATEOFBIRTH"),
                            rs.getString("ADDRESS"), rs.getString("PHONE"),
                            rs.getString("E_MAIL"),
                            rs.getString("SOCIAL_STATUS")
                    );

                    return p;
                }

            } catch (SQLException ex) {

            }

        } catch (Exception e) {

        }
        return null;
    }
    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

}
