/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.awt.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JFrame;

/**
 *
 * @author pc
 */
public class Appointments {

    private int APPOINTMENTNUMBER;
    private String APPOINTMENTTIME;
    private String DATEOFAPPOINTMENT;
    private int IDOFAPPOINTMENT;
    private String APPOINTMENTTYPE;
    private int CLINICNUM;
    private int PATIENTNUM;

    public Appointments() {
    }

    public Appointments(int APPOINTMENTNUMBER, String APPOINTMENTTIME, String DATEOFAPPOINTMENT, int IDOFAPPOINTMENT, String APPOINTMENTTYPE, int CLINICNUM, int PATIENTNUM) {
        this.APPOINTMENTNUMBER = APPOINTMENTNUMBER;
        this.APPOINTMENTTIME = APPOINTMENTTIME;
        this.DATEOFAPPOINTMENT = DATEOFAPPOINTMENT;
        this.IDOFAPPOINTMENT = IDOFAPPOINTMENT;
        this.APPOINTMENTTYPE = APPOINTMENTTYPE;
        this.CLINICNUM = CLINICNUM;
        this.PATIENTNUM = PATIENTNUM;
    }

    /**
     * @return the APPOINTMENTNUMBER
     */
    public int getAPPOINTMENTNUMBER() {
        return APPOINTMENTNUMBER;
    }

    /**
     * @param APPOINTMENTNUMBER the APPOINTMENTNUMBER to set
     */
    public void setAPPOINTMENTNUMBER(int APPOINTMENTNUMBER) {
        this.APPOINTMENTNUMBER = APPOINTMENTNUMBER;
    }

    /**
     * @return the APPOINTMENTTIME
     */
    public String getAPPOINTMENTTIME() {
        return APPOINTMENTTIME;
    }

    /**
     * @param APPOINTMENTTIME the APPOINTMENTTIME to set
     */
    public void setAPPOINTMENTTIME(String APPOINTMENTTIME) {
        this.APPOINTMENTTIME = APPOINTMENTTIME;
    }

    /**
     * @return the DATEOFAPPOINTMENT
     */
    public String getDATEOFAPPOINTMENT() {
        return DATEOFAPPOINTMENT;
    }

    /**
     * @param DATEOFAPPOINTMENT the DATEOFAPPOINTMENT to set
     */
    public void setDATEOFAPPOINTMENT(String DATEOFAPPOINTMENT) {
        this.DATEOFAPPOINTMENT = DATEOFAPPOINTMENT;
    }

    /**
     * @return the IDOFAPPOINTMENT
     */
    public int getIDOFAPPOINTMENT() {
        return IDOFAPPOINTMENT;
    }

    /**
     * @param IDOFAPPOINTMENT the IDOFAPPOINTMENT to set
     */
    public void setIDOFAPPOINTMENT(int IDOFAPPOINTMENT) {
        this.IDOFAPPOINTMENT = IDOFAPPOINTMENT;
    }

    /**
     * @return the APPOINTMENTTYPE
     */
    public String getAPPOINTMENTTYPE() {
        return APPOINTMENTTYPE;
    }

    /**
     * @param APPOINTMENTTYPE the APPOINTMENTTYPE to set
     */
    public void setAPPOINTMENTTYPE(String APPOINTMENTTYPE) {
        this.APPOINTMENTTYPE = APPOINTMENTTYPE;
    }

    /**
     * @return the CLINICNUM
     */
    public int getCLINICNUM() {
        return CLINICNUM;
    }

    /**
     * @param CLINICNUM the CLINICNUM to set
     */
    public void setCLINICNUM(int CLINICNUM) {
        this.CLINICNUM = CLINICNUM;
    }

    /**
     * @return the PATIENTNUM
     */
    public int getPATIENTNUM() {
        return PATIENTNUM;
    }

    /**
     * @param PATIENTNUM the PATIENTNUM to set
     */
    public void setPATIENTNUM(int PATIENTNUM) {
        this.PATIENTNUM = PATIENTNUM;
    }

    public int insertAppointment(JFrame frame) {
        int uID = 0;
        try {
            Appointments obj = this;
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;
            if (con != null) {
                String sql = "INSERT INTO SCHEDULEOFAPPOINTMENTSANDRESERVATIONS(IDOFAPPOINTMENT,"
                        + "APPOINTMENTTYPE,"
                        + "CLINICNUM,"
                        + "PATIENTNUM,DATEOFAPPOINTMENT"
                        + ")"
                        + " values (?,?,?,?,?)";
                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);
                pst.setInt(1, obj.IDOFAPPOINTMENT);
                pst.setString(2, obj.APPOINTMENTTYPE);
                pst.setInt(3, obj.CLINICNUM);
                pst.setInt(4, obj.PATIENTNUM);
                pst.setString(5, obj.DATEOFAPPOINTMENT);
                pst.execute();
                pst.close();
                sql = "Select APPOINTMENTNUMBER  from SCHEDULEOFAPPOINTMENTSANDRESERVATIONS order by  APPOINTMENTNUMBER desc";
                try {

                    pst = con.prepareStatement(sql);

                    ResultSet rsr = pst.executeQuery();

                    if (rsr.next()) {
                        uID = (int) rsr.getLong(1);
                        MessageManager.showSuccessMessage(frame, "Appointment added successfully");
                    }
                } catch (SQLException ex) {

                }
            }
            con.close();

        } catch (Exception we) {
            MessageManager.showFailedMessage(frame);
        }
        return uID;

    }

    public void updateAppointment(JFrame jFrame) {

    }

    public void DeleteAppointment(JFrame jFrame) {
    }

    public static ResultSet GetByPatientId(int id) {
        ResultSet rs = null;
        try {
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;

            if (con != null) {

                String sql = "select DOCTORSSCHEDUALE.TIMES,SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.APPOINTMENTTYPE,CLINIC.CLINICNAME from"
                        + " SCHEDULEOFAPPOINTMENTSANDRESERVATIONS inner join DOCTORSSCHEDUALE "
                        + "on DOCTORSSCHEDUALE.ID_NUMBER=SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.IDOFAPPOINTMENT join CLINIC on SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.CLINICNUM=CLINIC.CLINICNUMBER where SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.PATIENTNUM=?";

                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);
                pst.setInt(1, id);
                rs = pst.executeQuery();

            }

        } catch (Exception e) {

        }
        return rs;
    }
    public static ResultSet GetByPatientIdAndDoctorId(int id,int idDoctor) {
        ResultSet rs = null;
        try {
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;

            if (con != null) {

                String sql = "select DOCTORSSCHEDUALE.TIMES,SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.APPOINTMENTTYPE,CLINIC.CLINICNAME from SCHEDULEOFAPPOINTMENTSANDRESERVATIONS inner join DOCTORSSCHEDUALE "
                        + "on DOCTORSSCHEDUALE.ID_NUMBER=SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.IDOFAPPOINTMENT join CLINIC on SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.CLINICNUM=CLINIC.CLINICNUMBER where SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.PATIENTNUM=? and DOCTORSSCHEDUALE.ID_DOCTOR=?";

                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);
                pst.setInt(1, id);
                  pst.setInt(2, idDoctor);
                rs = pst.executeQuery();

            }

        } catch (Exception e) {

        }
        return rs;
    }

    public static ResultSet GetAppointmentByClinic(int id) {
        ResultSet rs = null;
        try {
            Connection.openConnection();
            java.sql.Connection con = Connection.conn2;

            if (con != null) {

                String sql = "select SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.DATEOFAPPOINTMENT,SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.APPOINTMENTTYPE,CLINIC.CLINICNAME from SCHEDULEOFAPPOINTMENTSANDRESERVATIONS inner join CLINIC on SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.CLINICNUM=CLINIC.CLINICNUMBER where SCHEDULEOFAPPOINTMENTSANDRESERVATIONS.CLINICNUM=?";

                PreparedStatement pst = null;
                pst = con.prepareStatement(sql);
                pst.setInt(1, id);
                rs = pst.executeQuery();

            }

        } catch (Exception e) {

        }
        return rs;
    }
}
