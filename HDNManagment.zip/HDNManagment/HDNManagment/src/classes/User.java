/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author pc
 */

public class User {
  public int UserID;
  public String Firstname;
  public String Lastname;
  public String gender;
  public String nationality;
  public String dateOfBirth;
  public String address;
  public String phone;
  public String email;
  public String socialStatus;
  public String userName;
  public String password;
  public String type;
  
    public User() {
    }

    public User(int UserID, String Fullname, String Lastname, String gender, String nationality, String dateOfBirth, String address, String phone, String email, String socialStatus, String userName, String password, String type) {
        this.UserID = UserID;
        this.Firstname = Fullname;
        this.Lastname = Lastname;
        this.gender = gender;
        this.nationality = nationality;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.socialStatus = socialStatus;
        this.userName = userName;
        this.password = password;
        this.type = type;
    }

    
    public int AddUser(String type,int userId,JFrame frame)
    {
        int uID=0;
          try
            {
                User user=this;
                Connection.openConnection();
                java.sql.Connection con=Connection.conn2;
                if(con!=null)
                {
                     String sql = "INSERT INTO UsersTBL(userName,password,USERTYPE,userId)"
                  + " values (?,?,?,?)";
           PreparedStatement pst=null;       
            pst=con.prepareStatement(sql);
           
            pst.setString(1,user.userName);
            pst.setString(2,user.password);
            pst.setString(3,type);
              pst.setInt(4,userId);
           

              pst.execute();
              pst.close();
             sql="Select USERNUMBER from UsersTbl order by USERNUMBER desc";
              try {
             
            pst = con.prepareStatement(sql);
             
            ResultSet rsr = pst.executeQuery();

            if (rsr.next()){
                uID= (int) rsr.getLong(1);
              }
             } catch (SQLException ex) {
           
                      }
                }
                con.close();
              
              
            }
            catch(Exception we)
            { 
                MessageManager.showFailedMessage(frame);  
            }
        return uID;
    }
      public boolean IsValid(JFrame jFrame)
    {
        /*
        boolean result=false;
         
                User customer=this;
                Connection.openConnection();
                 java.sql.Connection con=Connection.conn2;
                if(con!=null)
                {
                  String sql = "select * from UserTBL"
                          + " Where (UserName =? and Password =?) and (UserType='Admin')";
                  PreparedStatement pst=null;       
            try {
                pst=con.prepareStatement(sql);
                  pst.setString(1,this.userName);
                  pst.setString(2,this.password); 
                  ResultSet rs=null;
                  rs=pst.executeQuery();
                   
                   if(rs!=null)
                   {
                if(rs.next()){
               int id = rs.getInt("CustomerID");
               UserSession.UserId=id; 
               UserSession.userName=rs.getString("FName")+ " " +rs.getString("MName")+" "+rs.getString("LName");
               result= true;
                }
                   }
                else
                {
                     
                   result= false;
                }
            } catch (SQLException ex) {
                Logger.getLogger(MessageManager.class.getName()).log(Level.SEVERE, null, ex);
            }
    
               
            }
            else
            { 
                 MessageManager.showInvalid(jFrame);  
                result= false;
               
            }
               
        */
        return false;
    }
        public boolean IsValidManage(JFrame jFrame)
    {
        boolean result=false;
         
         AdminSession.isAdmin=false;
                User customer=this;
                Connection.openConnection();
                 java.sql.Connection con=Connection.conn2;
                if(con!=null)
                {
                  String sql = "select * from UsersTBL "
                          + " Where (UserName =? and Password =?)";
                  PreparedStatement pst=null;       
            try {
                pst=con.prepareStatement(sql);
                  pst.setString(1,this.userName);
                  pst.setString(2,this.password); 
                  ResultSet rs=null;
                  rs=pst.executeQuery();
                   
                   if(rs!=null)
                   {
                if(rs.next()){
                     result= true;
               int id = rs.getInt("USERID");
               AdminSession.userID=id;
               String type=rs.getString("USERTYPE");
               
               AdminSession.ManagmentUser=new User();
              
               AdminSession.ManagmentUser.UserID=id;
               this.UserID=id;
               AdminSession.ManagmentUser.userName=rs.getString("USERNAME");
               AdminSession.ManagmentUser.type=rs.getString("USERTYPE");
               result= true;
                }
                   }
                else
                {
                     
                   result= false;
                }
            } catch (SQLException ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }
    
               
            }
            else
            { 
                 MessageManager.showInvalid(jFrame);  
                result= false;
               
            }
               
        return result;
    }
      public void updateUser(JFrame jFrame)
    {
          try
            {
                User employee=this;
                Connection.openConnection();
                java.sql.Connection con=Connection.conn2;
                if(con!=null)
                {
                  String sql = "update UsersTbl set UserName='" + employee.userName+"'"+
                          " , Password='"+employee.password +"'"+
                          " where UserID=" + employee.UserID ;
           PreparedStatement pst=null;       
            pst=con.prepareStatement(sql);
           
        
          
              pst.executeUpdate();
              pst.close();
              MessageManager.showSuccessUpdateMessage(jFrame);
                }
                else
                {
                   MessageManager.showFailedMessage(jFrame);  
                }
                con.close();
            }
            catch(Exception we)
            { 
                MessageManager.showFailedMessage(jFrame);  
            }
          
    } 
}