/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author pc
 */
public class Connection {
    public static java.sql.Connection conn2;
    public static void openConnection()
    {
          try {
            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
            } catch (ClassNotFoundException ex) {
                
            }
            // connect method #2 - network client driver
            String dbURL2 = "jdbc:derby://localhost/hdn;create=true";
          
             conn2 = DriverManager.getConnection(dbURL2);
            if (conn2 != null) {
                System.out.println("Connected to database #2");
            }
 
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}


