/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author pc
 */
public class AdminSession {
    public static User admin=null;
    public static int low = 1;
    public static int high = 1000;
    public static User ManagmentUser;
    public static int userID = 0;
    public static boolean isAdmin = false;
    public static String adminName = "";
    public static int operation = 1;
    public static User user;
    public static Doctor doctor=null;
    public static Patient patient=null;
    public static Staff staff=null;
     public static String typePatient = "Patient";
     public static String typeDoctor = "Doctor";
     public static String typeStaff = "Staff";;
    public static boolean IsValidEmail(String email) {
        String regex = "^(.+)@(.+)$";
        //Compile regular expression to get the pattern  
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
    private static final String PHONE_NUMBER_GARBAGE_REGEX = "[()\\s-]+";
    private static final String PHONE_NUMBER_REGEX = "[0-9]+";
    private static final Pattern PHONE_NUMBER_PATTERN = Pattern.compile(PHONE_NUMBER_REGEX);

    public static boolean validatePhoneNumber(String phoneNumber) {
        return phoneNumber != null && PHONE_NUMBER_PATTERN.matcher(phoneNumber.replaceAll(PHONE_NUMBER_GARBAGE_REGEX, "")).matches();
    }

    public static String getCurrentDate() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        return (dtf.format(now));
    }
}
