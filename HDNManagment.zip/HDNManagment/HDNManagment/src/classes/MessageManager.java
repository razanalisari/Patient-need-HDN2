package classes;


import javax.swing.JFrame;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pc
 */
public class MessageManager {
     public static void ViewFrame(JFrame frame)
    {
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.pack();
       frame.setLocationRelativeTo(null);
       frame.setVisible(true);
    }
   
     public static void ChangeFrame(JFrame frame,JFrame old)
    {
      old.dispose();
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.pack();
       frame.setLocationRelativeTo(null); 
       frame.setVisible(true);
    }
        public static void showDuplicateMessage(JFrame frame)
     {
            JOptionPane.showMessageDialog(frame,
    "PassWord Not Match",
    "Failed",
    JOptionPane.ERROR_MESSAGE);
        
     }
    public static void showMissing(JFrame frame)
     {
            JOptionPane.showMessageDialog(frame,
    "Fill Info",
    "Failed",
    JOptionPane.ERROR_MESSAGE);
        
     }
          public static void showFailedMessage(JFrame frame)
     {
            JOptionPane.showMessageDialog(frame,
    "Error Connection to database",
    "Failed",
    JOptionPane.ERROR_MESSAGE);
        
     }
     public static void showFailedMessage(JFrame frame,String Message)
     {
            JOptionPane.showMessageDialog(frame,
    Message,
    "Failed",
    JOptionPane.ERROR_MESSAGE);
        
     }
      public static void showFailedImage(JFrame frame)
     {
            JOptionPane.showMessageDialog(frame,
    "You Must select photo",
    "Failed",
    JOptionPane.ERROR_MESSAGE);
        
     }
                  
    public static void showConfirmMessage(JFrame frame)
     {
            JOptionPane.showMessageDialog(frame,
    "You Must Confirm Agrement",
    "Failed",
    JOptionPane.ERROR_MESSAGE);
        
     }
  public static void showSuccessMessage(JFrame frame)
     {
            JOptionPane.showMessageDialog(frame,
    "Greate Information Added",
    "Success",
    JOptionPane.INFORMATION_MESSAGE);
        
     }
  public static void showSuccessDeleteMessage(JFrame frame)
     {
            JOptionPane.showMessageDialog(frame,
    "Information Deleted",
    "Success",
    JOptionPane.INFORMATION_MESSAGE);
        
     }
  
  public static void showInvalid(JFrame frame)
     {
            JOptionPane.showMessageDialog(frame,
    "Make Sure of User Name and Password",
    "Failed",
    JOptionPane.ERROR_MESSAGE);
        
     }
   public static void showInvalidCardMessage(JFrame frame)
     {
            JOptionPane.showMessageDialog(frame,
    "Your Card Is Expired",
    "Failed",
    JOptionPane.ERROR_MESSAGE);
        
     }
   public static void showInvalidPaymentMessage(JFrame frame)
     {
            JOptionPane.showMessageDialog(frame,
    "You Must select Payment Method",
    "Failed",
    JOptionPane.ERROR_MESSAGE);
        
     }
    
   
   public static void showSuccessUpdateMessage(JFrame frame)
     {
            JOptionPane.showMessageDialog(frame,
    "Information Updated",
    "Success",
    JOptionPane.INFORMATION_MESSAGE);
        
     }
   public static void showSuccessMessage(JFrame frame,String Message)
   {
       JOptionPane.showMessageDialog(frame,
    Message,
    "Success",
    JOptionPane.INFORMATION_MESSAGE);
   }
}

